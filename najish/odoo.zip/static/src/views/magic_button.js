/** @odoo-module **/

import { registry } from "@web/core/registry";
import { listView } from "@web/views/list/list_view";
import { ListRenderer } from "@web/views/list/list_renderer";
import { ListController } from "@web/views/list/list_controller";
import { ViewButton } from "@web/views/view_button/view_button";

alert("work 1");

export class SaleOrderMagicButton extends ViewButton {
  setup() {
    alert("work 2");
    super.setup();
  }

  async handleMagic() {
    alert("It worked");
  }
}

SaleOrderMagicButton.props = { ...ViewButton.props };
SaleOrderMagicButton.template = "najish.SaleOrderViewMagicButton";

registry
  .category("view_widgets")
  .add("sale_order_magic_button", SaleOrderMagicButton);

export class SaleOrderMagicButtonListRenderer extends ListRenderer {}

SaleOrderMagicButtonListRenderer.template = "najish.ListRenderer";
SaleOrderMagicButtonListRenderer.components = {
  ...ListRenderer.components,
};

export class SaleOrderMagicButtonListController extends ListController {}
SaleOrderMagicButtonListController.components = {
  ...ListController.components,
  SaleOrderMagicButton,
};

export const SaleOrderMagicButtonListView = {
  ...listView,
  Controller: SaleOrderMagicButtonListController,
  Renderer: SaleOrderMagicButtonListRenderer,
  buttonTemplate: "najish.ListView.Buttons",
};

registry
  .category("views")
  .add("sale_order_tree_magic", SaleOrderMagicButtonListView);
